<?php

namespace Tests\Unit\Http\Controllers\Api\V1;

use App\Domains\Core\Services\FeatureFlagService;
use App\Http\Controllers\Api\V1\FeatureFlagController;
use App\Models\Feature;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Mockery;
use Tests\TestCase;

class FeatureFlagControllerTest extends TestCase
{
    protected $featureFlagService;
    protected $controller;

    protected function setUp(): void
    {
        parent::setUp();
        
        // Use Mockery directly instead of Laravel's mock helper
        $this->featureFlagService = Mockery::mock(FeatureFlagService::class);
        $this->app->instance(FeatureFlagService::class, $this->featureFlagService);
        $this->controller = new FeatureFlagController($this->featureFlagService);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    public function test_index_returns_all_feature_flags()
    {
        // Arrange
        $flags = collect([
            new Feature(['name' => 'flag1', 'enabled' => true]),
            new Feature(['name' => 'flag2', 'enabled' => false]),
        ]);

        $this->featureFlagService
            ->expects('listAll')
            ->once()
            ->andReturn($flags);

        // Act
        $response = $this->controller->index();

        // Assert
        $this->assertEquals(200, $response->getStatusCode());
        $responseData = json_decode($response->getContent(), true);
        $this->assertTrue($responseData['success']);
    }

    public function test_check_returns_feature_status()
    {
        // Arrange
        $featureName = 'test_feature';
        $isActive = true;
        
        // Abordagem alternativa para mockar Auth
        Auth::spy();
        Auth::allows([
            'check' => true,
            'id' => 1,
        ]);

        $this->featureFlagService
            ->expects('isActive')
            ->once()
            ->with($featureName, 1)
            ->andReturn($isActive);

        // Act
        $response = $this->controller->check($featureName);

        // Assert
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_store_creates_or_updates_feature_flag_successfully()
    {
        // Arrange
        $requestData = [
            'name' => 'new_feature',
            'is_active' => true,
            'percentage' => 0,
            'expires_at' => null,
        ];
        $request = new Request($requestData);

        // Usar instância real com expectativas
        $validator = Mockery::mock();
        Validator::partialMock()->shouldReceive('make')->andReturn($validator);
        $validator->shouldReceive('fails')->andReturn(false);
        $validator->shouldReceive('validated')->andReturn($requestData);

        $this->featureFlagService
            ->expects('createOrUpdate')
            ->once()
            ->andReturn(new Feature($requestData));

        // Act
        $response = $this->controller->store($request);

        // Assert
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_store_returns_error_on_validation_failure()
    {
        // Arrange
        $requestData = [
            'name' => '', // Invalid
            'is_active' => 'not_a_boolean', // Invalid
        ];
        $request = new Request($requestData);

        // Mock Validator to fail
        $validator = Mockery::mock();
        $errors = Mockery::mock();
        
        Validator::partialMock()->shouldReceive('make')->andReturn($validator);
        $validator->shouldReceive('fails')->andReturn(true);
        $validator->shouldReceive('errors')->andReturn($errors);
        $errors->shouldReceive('toArray')->andReturn([
            'name' => ['The name field is required.'],
        ]);

        // Act
        $response = $this->controller->store($request);

        // Assert
        $this->assertEquals(422, $response->getStatusCode());
    }

    public function test_enable_for_user_enables_feature_for_user()
    {
        // Arrange
        $requestData = [
            'name' => 'feature_for_user',
            'user_id' => 1,
        ];
        $request = new Request($requestData);

        $validator = Mockery::mock();
        Validator::partialMock()->shouldReceive('make')->andReturn($validator);
        $validator->shouldReceive('fails')->andReturn(false);
        $validator->shouldReceive('validated')->andReturn($requestData);

        $this->featureFlagService
            ->expects('enableForUser')
            ->once()
            ->with('feature_for_user', 1)
            ->andReturn(true);

        // Act
        $response = $this->controller->enableForUser($request);

        // Assert
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_disable_for_user_disables_feature_for_user()
    {
        // Arrange
        $requestData = [
            'name' => 'feature_for_user',
            'user_id' => 1,
        ];
        $request = new Request($requestData);

        $validator = Mockery::mock();
        Validator::partialMock()->shouldReceive('make')->andReturn($validator);
        $validator->shouldReceive('fails')->andReturn(false);
        $validator->shouldReceive('validated')->andReturn($requestData);

        $this->featureFlagService
            ->expects('disableForUser')
            ->once()
            ->with('feature_for_user', 1)
            ->andReturn(true);

        // Act
        $response = $this->controller->disableForUser($request);

        // Assert
        $this->assertEquals(200, $response->getStatusCode());
    }
}