<?php

namespace Tests\Unit\Repositories\Eloquent;

use App\Models\Profile;
use App\Models\User;
use App\Repositories\Eloquent\EloquentProfileRepository;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class EloquentProfileRepositoryTest extends TestCase
{
    use RefreshDatabase;

    protected EloquentProfileRepository $profileRepository;
    protected User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->profileRepository = new EloquentProfileRepository(new Profile());
        $this->user = User::factory()->create();
    }

    /** @test */
    public function test_find_by_id_returns_profile_when_found(): void
    {
        // Arrange
        $profile = Profile::factory()->create(['user_id' => $this->user->id]);

        // Act
        $foundProfile = $this->profileRepository->findById($profile->id);

        // Assert
        $this->assertInstanceOf(Profile::class, $foundProfile);
        $this->assertEquals($profile->id, $foundProfile->id);
    }

    /** @test */
    public function test_find_by_id_returns_null_when_profile_not_found(): void
    {
        // Act
        $foundProfile = $this->profileRepository->findById(999);

        // Assert
        $this->assertNull($foundProfile);
    }

    /** @test */
    public function test_find_by_user_id_returns_profile_when_found(): void
    {
        // Arrange
        $profile = Profile::factory()->create(['user_id' => $this->user->id]);

        // Act
        $foundProfile = $this->profileRepository->findByUserId($this->user->id);

        // Assert
        $this->assertInstanceOf(Profile::class, $foundProfile);
        $this->assertEquals($profile->id, $foundProfile->id);
        $this->assertEquals($this->user->id, $foundProfile->user_id);
    }

    /** @test */
    public function test_find_by_user_id_returns_null_when_profile_not_found(): void
    {
        // Act
        $foundProfile = $this->profileRepository->findByUserId(999); // User ID that doesn't exist

        // Assert
        $this->assertNull($foundProfile);
    }

    /** @test */
    public function test_create_profile_successfully(): void
    {
        // Arrange
        $user = User::factory()->create();
        $profileData = [
            'user_id' => $user->id,
            'bio' => 'New profile bio',
            'phone' => '1234567890'
        ];

        // Act
        $profile = $this->profileRepository->create($profileData);

        // Assert
        $this->assertInstanceOf(Profile::class, $profile);
        $this->assertEquals($user->id, $profile->user_id);
        $this->assertEquals('New profile bio', $profile->bio);
        $this->assertDatabaseHas('profiles', $profileData);
    }

    /** @test */
    public function test_update_profile_successfully(): void
    {
        // Arrange
        $profile = Profile::factory()->create(['user_id' => $this->user->id, 'bio' => 'Old bio']);
        $updateData = ['bio' => 'Updated bio content', 'phone' => '987654321'];

        // Act
        $result = $this->profileRepository->update($profile, $updateData);

        // Assert
        $this->assertTrue($result);
        $this->assertDatabaseHas('profiles', [
            'id' => $profile->id,
            'bio' => 'Updated bio content',
            'phone' => '987654321'
        ]);
    }

    /** @test */
    public function test_delete_profile_successfully(): void
    {
        // Arrange
        $profile = Profile::factory()->create(['user_id' => $this->user->id]);

        // Act
        $result = $this->profileRepository->delete($profile);

        // Assert
        $this->assertTrue($result);
        $this->assertDatabaseMissing('profiles', ['id' => $profile->id]);
    }
}