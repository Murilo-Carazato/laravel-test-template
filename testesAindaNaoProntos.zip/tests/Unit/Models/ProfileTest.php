<?php

namespace Tests\Unit\Models;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProfileTest extends TestCase
{
    use RefreshDatabase;

    protected Profile $profile;
    protected User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->user = User::factory()->create();
        $this->profile = Profile::factory()->create(['user_id' => $this->user->id]);
    }

    /** @test */
    public function it_has_fillable_attributes(): void
    {
        $fillable = [
            'user_id',
            'bio',
            'phone',
            'avatar',
            'address',
            'city',
            'state',
            'zip_code',
            'preferences'
        ];

        $this->assertEquals($fillable, $this->profile->getFillable());
    }

    /** @test */
    public function it_has_casts(): void
    {
        $casts = [
            'preferences' => 'array',
        ];

        foreach ($casts as $key => $value) {
            $this->assertArrayHasKey($key, $this->profile->getCasts());
            $this->assertEquals($value, $this->profile->getCasts()[$key]);
        }
    }

    /** @test */
    public function it_belongs_to_a_user(): void
    {
        $this->assertInstanceOf(User::class, $this->profile->user);
        $this->assertEquals($this->user->id, $this->profile->user->id);
    }

    /** @test */
    public function it_can_create_a_profile_with_valid_data(): void
    {
        $user = User::factory()->create();
        $profileData = [
            'user_id' => $user->id,
            'bio' => 'A new bio for a new user.',
            'phone' => '9876543210',
            'preferences' => ['theme' => 'light']
        ];

        $profile = Profile::create($profileData);

        $this->assertInstanceOf(Profile::class, $profile);
        $this->assertEquals($user->id, $profile->user_id);
        $this->assertEquals('A new bio for a new user.', $profile->bio);
        $this->assertEquals('9876543210', $profile->phone);
        $this->assertEquals(['theme' => 'light'], $profile->preferences);
        $this->assertDatabaseHas('profiles', ['user_id' => $user->id, 'bio' => 'A new bio for a new user.']);
    }

    /** @test */
    public function it_can_update_profile_attributes(): void
    {
        $this->profile->update([
            'bio' => 'Updated bio content',
            'phone' => '1122334455',
        ]);

        $this->assertEquals('Updated bio content', $this->profile->fresh()->bio);
        $this->assertEquals('1122334455', $this->profile->fresh()->phone);
        $this->assertDatabaseHas('profiles', [
            'id' => $this->profile->id,
            'bio' => 'Updated bio content',
            'phone' => '1122334455'
        ]);
    }

    /** @test */
    public function it_handles_json_casting_for_preferences(): void
    {
        $preferences = ['notifications' => true, 'language' => 'en'];
        $this->profile->update(['preferences' => $preferences]);

        $this->assertIsArray($this->profile->fresh()->preferences);
        $this->assertEquals($preferences, $this->profile->fresh()->preferences);
    }
}