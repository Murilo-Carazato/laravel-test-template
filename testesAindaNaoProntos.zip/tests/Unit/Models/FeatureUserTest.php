<?php

namespace Tests\Unit\Models;

use App\Models\Feature;
use App\Models\FeatureUser;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FeatureUserTest extends TestCase
{
    use RefreshDatabase;

    protected FeatureUser $featureUser;
    protected User $user;
    protected Feature $feature;

    protected function setUp(): void
    {
        parent::setUp();
        $this->user = User::factory()->create();
        $this->feature = Feature::factory()->create(['name' => 'test_feature']);
        $this->featureUser = FeatureUser::create([
            'user_id' => $this->user->id,
            'feature_name' => $this->feature->name,
            'enabled' => true,
        ]);
    }

    /** @test */
    public function it_uses_timestamps(): void
    {
        $this->assertTrue($this->featureUser->timestamps);
        $this->assertNotNull($this->featureUser->created_at);
        $this->assertNotNull($this->featureUser->updated_at);
    }

    /** @test */
    public function it_has_casts(): void
    {
        $casts = [
            'enabled' => 'boolean',
        ];

        foreach ($casts as $key => $value) {
            $this->assertArrayHasKey($key, $this->featureUser->getCasts());
            $this->assertEquals($value, $this->featureUser->getCasts()[$key]);
        }
    }

    /** @test */
    public function it_belongs_to_a_feature(): void
    {
        $this->assertInstanceOf(Feature::class, $this->featureUser->feature);
        $this->assertEquals($this->feature->name, $this->featureUser->feature->name);
    }

    /** @test */
    public function it_belongs_to_a_user(): void
    {
        $this->assertInstanceOf(User::class, $this->featureUser->user);
        $this->assertEquals($this->user->id, $this->featureUser->user->id);
    }

    /** @test */
    public function it_can_be_created_with_valid_data(): void
    {
        $newUser = User::factory()->create();
        $newFeature = Feature::factory()->create(['name' => 'another_feature']);

        $newFeatureUser = FeatureUser::create([
            'user_id' => $newUser->id,
            'feature_name' => $newFeature->name,
            'enabled' => false,
        ]);

        $this->assertInstanceOf(FeatureUser::class, $newFeatureUser);
        $this->assertEquals($newUser->id, $newFeatureUser->user_id);
        $this->assertEquals($newFeature->name, $newFeatureUser->feature_name);
        $this->assertFalse($newFeatureUser->enabled);
        $this->assertDatabaseHas('feature_user', [
            'user_id' => $newUser->id,
            'feature_name' => $newFeature->name,
            'enabled' => false,
        ]);
    }

    /** @test */
    public function it_can_be_updated(): void
    {
        $this->featureUser->update(['enabled' => false]);

        $this->assertFalse($this->featureUser->fresh()->enabled);
        $this->assertDatabaseHas('feature_user', [
            'id' => $this->featureUser->id,
            'enabled' => false,
        ]);
    }
}