<?php

namespace Tests\Unit\Models;

use App\Models\Feature;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FeatureTest extends TestCase
{
    use RefreshDatabase;

    protected Feature $feature;

    protected function setUp(): void
    {
        parent::setUp();
        $this->feature = Feature::factory()->create([
            'name' => 'test_feature',
            'enabled' => true,
            'description' => 'A test feature',
        ]);
    }

    /** @test */
    public function it_has_fillable_attributes(): void
    {
        $fillable = [
            'name',
            'enabled',
            'description',
        ];

        $this->assertEquals($fillable, $this->feature->getFillable());
    }

    /** @test */
    public function it_has_casts(): void
    {
        $casts = [
            'enabled' => 'boolean',
        ];

        foreach ($casts as $key => $value) {
            $this->assertArrayHasKey($key, $this->feature->getCasts());
            $this->assertEquals($value, $this->feature->getCasts()[$key]);
        }
    }

    /** @test */
    public function it_has_users_relationship(): void
    {
        $user = User::factory()->create();
        $this->feature->users()->attach($user->id, ['enabled' => true]);

        $this->assertInstanceOf(\Illuminate\Database\Eloquent\Collection::class, $this->feature->users);
        $this->assertCount(1, $this->feature->users);
        $this->assertEquals($user->id, $this->feature->users->first()->id);
        $this->assertTrue($this->feature->users->first()->pivot->enabled);
    }

    /** @test */
    public function test_is_enabled_for_user_uses_global_setting_if_no_override(): void
    {
        // Arrange
        $user = User::factory()->create();
        $featureEnabled = Feature::factory()->create(['name' => 'feature_enabled', 'enabled' => true]);
        $featureDisabled = Feature::factory()->create(['name' => 'feature_disabled', 'enabled' => false]);

        // Act & Assert
        $this->assertTrue($featureEnabled->isEnabledForUser($user));
        $this->assertFalse($featureDisabled->isEnabledForUser($user));
    }

    /** @test */
    public function test_is_enabled_for_user_uses_user_override_when_enabled(): void
    {
        // Arrange
        $user = User::factory()->create();
        $feature = Feature::factory()->create(['name' => 'override_feature', 'enabled' => false]); // Global disabled
        $feature->users()->attach($user->id, ['enabled' => true]); // User override enabled

        // Act & Assert
        $this->assertTrue($feature->isEnabledForUser($user));
    }

    /** @test */
    public function test_is_enabled_for_user_uses_user_override_when_disabled(): void
    {
        // Arrange
        $user = User::factory()->create();
        $feature = Feature::factory()->create(['name' => 'override_feature_2', 'enabled' => true]); // Global enabled
        $feature->users()->attach($user->id, ['enabled' => false]); // User override disabled

        // Act & Assert
        $this->assertFalse($feature->isEnabledForUser($user));
    }

    /** @test */
    public function test_is_enabled_for_user_with_null_user_uses_global_setting(): void
    {
        // Arrange
        $featureEnabled = Feature::factory()->create(['name' => 'global_only_enabled', 'enabled' => true]);
        $featureDisabled = Feature::factory()->create(['name' => 'global_only_disabled', 'enabled' => false]);

        // Act & Assert
        $this->assertTrue($featureEnabled->isEnabledForUser(null));
        $this->assertFalse($featureDisabled->isEnabledForUser(null));
    }
}