<?php

namespace Tests\Unit\Domains\Core\Services;

use App\Domains\Core\Services\FeatureFlagService;
use App\Models\Feature;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Mockery;
use Tests\TestCase;

class FeatureFlagServiceTest extends TestCase
{
    use RefreshDatabase;

    protected FeatureFlagService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new FeatureFlagService();
        Cache::fake(); // Mock the Cache facade
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /** @test */
    public function test_get_all_features_caches_results(): void
    {
        // Arrange
        Feature::factory()->count(2)->create();

        // Act
        $features1 = $this->service->getAllFeatures();
        $features2 = $this->service->getAllFeatures(); // Should hit cache

        // Assert
        Cache::shouldHaveReceived('remember')
            ->once()
            ->with('features.all', Mockery::any(), Mockery::type('callable'));
        $this->assertCount(2, $features1);
        $this->assertEquals($features1, $features2);
    }

    /** @test */
    public function test_is_enabled_checks_user_override_then_global(): void
    {
        // Arrange
        $user = User::factory()->create();
        $feature = Feature::factory()->create(['name' => 'test_feature', 'enabled' => true]);

        // Scenario 1: No user override, global is enabled
        Cache::shouldReceive('remember')
            ->once()
            ->with("feature.test_feature.user.{$user->id}", Mockery::any(), Mockery::type('callable'))
            ->andReturn(null); // No user override
        Cache::shouldReceive('remember')
            ->once()
            ->with("feature.test_feature", Mockery::any(), Mockery::type('callable'))
            ->andReturn(true); // Global enabled

        // Act & Assert
        $this->assertTrue($this->service->isEnabled('test_feature', $user->id));

        // Scenario 2: User override disables it
        Cache::shouldReceive('remember')
            ->once()
            ->with("feature.test_feature.user.{$user->id}", Mockery::any(), Mockery::type('callable'))
            ->andReturn(false); // User override disables
        Cache::shouldNotReceive('remember')
            ->with("feature.test_feature", Mockery::any(), Mockery::type('callable')); // Global not checked

        // Act & Assert
        $this->assertFalse($this->service->isEnabled('test_feature', $user->id));

        // Scenario 3: User override enables it, global is disabled
        $feature->update(['enabled' => false]); // Global disabled
        Cache::forget("feature.test_feature"); // Clear global cache

        Cache::shouldReceive('remember')
            ->once()
            ->with("feature.test_feature.user.{$user->id}", Mockery::any(), Mockery::type('callable'))
            ->andReturn(true); // User override enables
        Cache::shouldNotReceive('remember')
            ->with("feature.test_feature", Mockery::any(), Mockery::type('callable')); // Global not checked

        // Act & Assert
        $this->assertTrue($this->service->isEnabled('test_feature', $user->id));
    }

    /** @test */
    public function test_create_or_update_creates_new_feature(): void
    {
        // Arrange
        $name = 'new_feature';
        $enabled = true;
        $description = 'A brand new feature';

        // Act
        $feature = $this->service->createOrUpdate($name, $enabled, $description);

        // Assert
        $this->assertInstanceOf(Feature::class, $feature);
        $this->assertEquals($name, $feature->name);
        $this->assertTrue($feature->enabled);
        $this->assertEquals($description, $feature->description);
        $this->assertDatabaseHas('features', ['name' => $name, 'enabled' => true, 'description' => $description]);
        Cache::assertForgotten("feature.{$name}");
        Cache::assertForgotten('features.all');
    }

    /** @test */
    public function test_create_or_update_updates_existing_feature(): void
    {
        // Arrange
        $feature = Feature::factory()->create(['name' => 'existing_feature', 'enabled' => false, 'description' => 'Old description']);
        $name = 'existing_feature';
        $enabled = true;
        $description = 'Updated description';

        // Act
        $updatedFeature = $this->service->createOrUpdate($name, $enabled, $description);

        // Assert
        $this->assertInstanceOf(Feature::class, $updatedFeature);
        $this->assertEquals($feature->id, $updatedFeature->id);
        $this->assertTrue($updatedFeature->enabled);
        $this->assertEquals($description, $updatedFeature->description);
        $this->assertDatabaseHas('features', ['id' => $feature->id, 'enabled' => true, 'description' => $description]);
        Cache::assertForgotten("feature.{$name}");
        Cache::assertForgotten('features.all');
    }

    /** @test */
    public function test_create_or_update_with_expiration_date(): void
    {
        // Arrange
        $name = 'expiring_feature';
        $enabled = true;
        $expiresAt = Carbon::now()->addDays(7);

        // Act
        $feature = $this->service->createOrUpdate($name, $enabled, null, $expiresAt);

        // Assert
        $this->assertInstanceOf(Feature::class, $feature);
        $this->assertEquals($expiresAt->toDateTimeString(), $feature->expires_at->toDateTimeString());
        $this->assertDatabaseHas('features', ['name' => $name, 'expires_at' => $expiresAt->toDateTimeString()]);
    }

    /** @test */
    public function test_enable_for_user_enables_feature_for_specific_user(): void
    {
        // Arrange
        $user = User::factory()->create();
        $feature = Feature::factory()->create(['name' => 'user_specific_feature', 'enabled' => false]);

        // Act
        $result = $this->service->enableForUser('user_specific_feature', $user->id);

        // Assert
        $this->assertTrue($result);
        $this->assertDatabaseHas('feature_user', [
            'user_id' => $user->id,
            'feature_name' => 'user_specific_feature',
            'enabled' => true,
        ]);
        Cache::assertForgotten("feature.user_specific_feature.user.{$user->id}");
    }

    /** @test */
    public function test_disable_for_user_disables_feature_for_specific_user(): void
    {
        // Arrange
        $user = User::factory()->create();
        $feature = Feature::factory()->create(['name' => 'user_specific_feature', 'enabled' => true]);
        $feature->users()->syncWithoutDetaching([$user->id => ['enabled' => true]]); // Ensure it's enabled for user

        // Act
        $result = $this->service->disableForUser('user_specific_feature', $user->id);

        // Assert
        $this->assertTrue($result);
        $this->assertDatabaseHas('feature_user', [
            'user_id' => $user->id,
            'feature_name' => 'user_specific_feature',
            'enabled' => false,
        ]);
        Cache::assertForgotten("feature.user_specific_feature.user.{$user->id}");
    }

    /** @test */
    public function test_enable_for_user_returns_false_if_feature_not_found(): void
    {
        // Arrange
        $user = User::factory()->create();

        // Act
        $result = $this->service->enableForUser('non_existent_feature', $user->id);

        // Assert
        $this->assertFalse($result);
        $this->assertDatabaseMissing('feature_user', ['user_id' => $user->id, 'feature_name' => 'non_existent_feature']);
    }

    /** @test */
    public function test_list_all_returns_all_features(): void
    {
        // Arrange
        Feature::factory()->count(3)->create();

        // Act
        $features = $this->service->listAll();

        // Assert
        $this->assertCount(3, $features);
        $this->assertInstanceOf(\Illuminate\Database\Eloquent\Collection::class, $features);
    }
}