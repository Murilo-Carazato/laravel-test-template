<?php

namespace Tests\Unit\Domains\Core\Services;

use Tests\TestCase;
use App\Domains\Core\Services\FileStorageService;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Queue; // Importar Queue para dispatch
use Mockery; // Importar Mockery

class FileStorageServiceTest extends TestCase
{
    protected FileStorageService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new FileStorageService();
        Storage::fake('public'); // Falsifica o disco 'public'
        Storage::fake('s3'); // Falsifica o disco 's3'
        Log::fake(); // Falsifica o log
        Queue::fake(); // Falsifica a fila
        Str::shouldReceive('uuid')->andReturn('test-uuid'); // Moca UUID para previsibilidade
    }

    /** @test */
    public function it_checks_if_file_is_allowed_by_mime_type(): void
    {
        $file = UploadedFile::fake()->image('avatar.jpg');
        $this->assertTrue($this->service->isAllowedFile($file));

        $file = UploadedFile::fake()->create('document.pdf', 100, 'application/pdf');
        $this->assertTrue($this->service->isAllowedFile($file));

        $file = UploadedFile::fake()->create('script.sh', 100, 'application/x-sh');
        $this->assertFalse($this->service->isAllowedFile($file));
    }

    /** @test */
    public function it_checks_if_file_is_allowed_with_custom_mime_types(): void
    {
        $file = UploadedFile::fake()->create('config.json', 100, 'application/json');
        $allowed = ['application/json'];
        $this->assertTrue($this->service->isAllowedFile($file, $allowed));

        $file = UploadedFile::fake()->image('image.webp');
        $allowed = ['image/jpeg']; // WebP não está em allowed, mas jpeg sim
        $this->assertFalse($this->service->isAllowedFile($file, $allowed));
    }

    /** @test */
    public function it_stores_a_file_with_generated_name(): void
    {
        // Arrange
        $file = UploadedFile::fake()->image('my_image.png');
        $path = 'avatars';
        $disk = 'public';

        // Act
        $storedPath = $this->service->store($file, $path, $disk, false);

        // Assert
        $expectedFileName = 'test-uuid.png';
        Storage::assertExists("{$path}/{$expectedFileName}");
        $this->assertEquals("{$path}/{$expectedFileName}", $storedPath);
    }

    /** @test */
    public function it_stores_a_file_with_preserved_and_sanitized_name(): void
    {
        // Arrange
        $file = UploadedFile::fake()->create('My_Docu ment!.pdf', 100, 'application/pdf');
        $path = 'documents';
        $disk = 'public';

        // Act
        $storedPath = $this->service->store($file, $path, $disk, true);

        // Assert
        $expectedFileName = 'My_Docu_ment_.pdf'; // Nome sanitizado
        Storage::assertExists("{$path}/{$expectedFileName}");
        $this->assertEquals("{$path}/{$expectedFileName}", $storedPath);
    }

    /** @test */
    public function it_throws_exception_for_disallowed_file_type_on_store(): void
    {
        // Arrange
        $file = UploadedFile::fake()->create('malicious.exe', 100, 'application/x-dosexec');
        $path = 'uploads';
        $disk = 'public';

        Log::shouldReceive('warning') // Espera que um log de warning seja gerado
            ->once()
            ->withArgs(function ($message, $context) use ($file) {
                return str_contains($message, 'Tentativa de upload de arquivo com tipo não permitido') &&
                       $context['mime_type'] === $file->getMimeType();
            });

        // Act & Assert
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Tipo de arquivo não permitido: application/x-dosexec');

        $this->service->store($file, $path, $disk);
    }

    /** @test */
    public function it_sanitizes_various_file_names(): void
    {
        // Usando Reflection para testar método protegido
        $sanitizeMethod = new \ReflectionMethod(FileStorageService::class, 'sanitizeFileName');
        $sanitizeMethod->setAccessible(true);

        $this->assertEquals('my_file.txt', $sanitizeMethod->invoke($this->service, 'my_file.txt'));
        $this->assertEquals('my_file_with_spaces.txt', $sanitizeMethod->invoke($this->service, 'my file with spaces.txt'));
        $this->assertEquals('my_file_with_special_chars_.txt', $sanitizeMethod->invoke($this->service, 'my_file_with_special_chars-!.txt'));
        $this->assertEquals('file_.hidden_file.env', $sanitizeMethod->invoke($this->service, '.hidden_file.env')); // Adiciona 'file_' para ocultos
        $this->assertEquals('file_path_to_file.zip', $sanitizeMethod->invoke($this->service, '/path/to/file.zip')); // Remove barras
    }

    /** @test */
    public function it_stores_temporary_files_and_dispatches_delete_job(): void
    {
        // Arrange
        $file = UploadedFile::fake()->image('temp_image.png');
        $expiryMinutes = 10;

        // Mock the Storage facade
        Storage::shouldReceive('disk->put')
            ->once()
            ->with("temp/test-uuid.png", Mockery::any())
            ->andReturn(true);

        Storage::shouldReceive('disk->url')
            ->once()
            ->with("temp/test-uuid.png")
            ->andReturn('http://localhost/storage/temp/test-uuid.png');

        Queue::shouldReceive('dispatch') // Verifica que o job é despachado
            ->once()
            ->andReturnUsing(function ($callback) use ($expiryMinutes) {
                // Assert that the dispatched item is a closure with a delay
                $this->assertInstanceOf(\Closure::class, $callback);
                // Cannot directly assert the delay of a closure, but can assert the dispatch call itself
                // The delay() method is chained after dispatch(), so we check dispatch was called.
            });

        // Act
        $temporaryUrl = $this->service->storeTemporary($file, $expiryMinutes);

        // Assert
        $this->assertEquals('http://localhost/storage/temp/test-uuid.png', $temporaryUrl);
        // Assert that the delete logic inside the dispatched closure is correctly setup
        // We'd typically test the closure itself if we had direct access to it
        // Queue::assertPushedOn('default', function($job) { /* check closure content */ }); is harder with anonymous closures
        // but the core logic is in FileStorageService, not the Queue itself.
    }
    
    /** @test */
    public function it_deletes_a_file(): void
    {
        // Arrange
        Storage::disk('public')->put('path/to/file.txt', 'content');
        $this->assertTrue(Storage::disk('public')->exists('path/to/file.txt'));

        // Act
        $result = $this->service->delete('path/to/file.txt', 'public');

        // Assert
        $this->assertTrue($result);
        Storage::assertMissing('path/to/file.txt');
    }

    /** @test */
    public function it_checks_if_a_file_exists(): void
    {
        // Arrange
        Storage::disk('public')->put('path/to/another_file.txt', 'content');

        // Act & Assert
        $this->assertTrue($this->service->exists('path/to/another_file.txt', 'public'));
        $this->assertFalse($this->service->exists('path/to/non_existent.txt', 'public'));
    }

    /** @test */
    public function it_generates_temporary_url(): void
    {
        // Arrange
        $path = 'private/report.pdf';
        $expiration = now()->addHours(1);
        $disk = 's3';
        $expectedUrl = 'https://s3.aws.com/temp_signed_url';
        Storage::shouldReceive('disk->temporaryUrl')
            ->once()
            ->with($path, Mockery::on(function ($arg) use ($expiration) {
                return $arg instanceof \DateTimeInterface && $arg->getTimestamp() === $expiration->getTimestamp();
            }))
            ->andReturn($expectedUrl);

        // Act
        $url = $this->service->temporaryUrl($path, $expiration, $disk);

        // Assert
        $this->assertEquals($expectedUrl, $url);
    }

    /** @test */
    public function it_sets_allowed_mime_types(): void
    {
        // Arrange
        $customTypes = ['application/xml', 'text/csv'];
        
        // Use reflection to access the protected property
        $reflection = new \ReflectionClass($this->service);
        $property = $reflection->getProperty('allowedMimeTypes');
        $property->setAccessible(true);

        // Act
        $this->service->setAllowedMimeTypes($customTypes);

        // Assert
        $this->assertEquals($customTypes, $property->getValue($this->service));

        // Test with a file to ensure the new types are effective
        $file = UploadedFile::fake()->create('data.csv', 10, 'text/csv');
        $this->assertTrue($this->service->isAllowedFile($file));

        $file = UploadedFile::fake()->image('image.jpeg'); // Originalmente permitido, agora não
        $this->assertFalse($this->service->isAllowedFile($file));
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }
}