<?php

namespace Tests\Unit\Services;

use Tests\TestCase;
use App\Domains\Core\Services\CacheService;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Redis; // Importar Redis
use Illuminate\Database\Eloquent\Model; // Importar Model
use Illuminate\Support\Collection; // Importar Collection
use Mockery; // Importar Mockery

class CacheServiceTest extends TestCase
{
    protected CacheService $cacheService;

    protected function setUp(): void
    {
        parent::setUp();
        Cache::fake(); // Falsifica a facade Cache
        Redis::fake(); // Falsifica a facade Redis
        config(['cache.default' => 'array']); // Configura o driver de cache para 'array' por padrão

        $this->cacheService = new CacheService('my_app');
    }

    /** @test */
    public function it_remembers_value_from_cache(): void
    {
        // Arrange
        $key = 'test_key';
        $value = 'cached_value';
        $callback = fn () => 'new_value'; // This should not be called

        Cache::shouldReceive('remember')
            ->once()
            ->with("my_app:{$key}", 60 * 60, Mockery::type('callable'))
            ->andReturn($value);

        // Act
        $result = $this->cacheService->remember($key, $callback);

        // Assert
        $this->assertEquals($value, $result);
    }

    /** @test */
    public function it_puts_value_into_cache(): void
    {
        // Arrange
        $key = 'put_key';
        $value = 'put_value';
        Cache::shouldReceive('put')
            ->once()
            ->with("my_app:{$key}", $value, 60 * 60)
            ->andReturn(true);

        // Act
        $result = $this->cacheService->put($key, $value);

        // Assert
        $this->assertTrue($result);
    }

    /** @test */
    public function it_checks_if_item_exists_in_cache(): void
    {
        // Arrange
        $key = 'has_key';
        Cache::shouldReceive('has')
            ->once()
            ->with("my_app:{$key}")
            ->andReturn(true);

        // Act
        $result = $this->cacheService->has($key);

        // Assert
        $this->assertTrue($result);
    }

    /** @test */
    public function it_gets_item_from_cache(): void
    {
        // Arrange
        $key = 'get_key';
        $value = 'retrieved_value';
        Cache::shouldReceive('get')
            ->once()
            ->with("my_app:{$key}", null)
            ->andReturn($value);

        // Act
        $result = $this->cacheService->get($key);

        // Assert
        $this->assertEquals($value, $result);
    }

    /** @test */
    public function it_forgets_item_from_cache(): void
    {
        // Arrange
        $key = 'forget_key';
        Cache::shouldReceive('forget')
            ->once()
            ->with("my_app:{$key}")
            ->andReturn(true);

        // Act
        $result = $this->cacheService->forget($key);

        // Assert
        $this->assertTrue($result);
    }

    /** @test */
    public function it_flushes_redis_cache_by_pattern(): void
    {
        // Arrange
        config(['cache.default' => 'redis']);
        $pattern = 'users:*';
        $redisMock = Mockery::mock(\Illuminate\Redis\Connections\Connection::class);
        $redisMock->shouldReceive('keys')->once()->with("my_app:{$pattern}*")->andReturn(['key1', 'key2']);
        $redisMock->shouldReceive('del')->once()->with(['key1', 'key2'])->andReturn(2);
        
        Cache::shouldReceive('getRedis')->andReturn($redisMock);

        // Act
        $result = $this->cacheService->flush($pattern);

        // Assert
        $this->assertTrue($result);
    }

    /** @test */
    public function it_flushes_all_cache_for_non_redis_drivers(): void
    {
        // Arrange
        config(['cache.default' => 'file']); // Non-redis driver
        Cache::shouldReceive('flush')->once()->andReturn(true);

        // Act
        $result = $this->cacheService->flush('any_pattern');

        // Assert
        $this->assertTrue($result);
    }

    /** @test */
    public function it_generates_model_cache_key(): void
    {
        // Arrange
        $model = Mockery::mock(Model::class);
        $model->shouldReceive('getKey')->andReturn(1);
        $model->shouldReceive('get_class')->andReturn('App\\Models\\User'); // Simula get_class

        // Act
        $key = $this->cacheService->generateModelKey($model);

        // Assert
        $this->assertEquals('App\\Models\\User:1', $key);
    }

    /** @test */
    public function it_generates_collection_cache_key_for_empty_collection(): void
    {
        // Arrange
        $collection = new Collection();

        // Act
        $key = $this->cacheService->generateCollectionKey($collection, 'empty_users');

        // Assert
        $this->assertEquals('Collection:empty:empty_users', $key);
    }

    /** @test */
    public function it_generates_collection_cache_key_for_non_empty_collection(): void
    {
        // Arrange
        $item1 = (object)['id' => 1, 'name' => 'Item A'];
        $item2 = (object)['id' => 2, 'name' => 'Item B'];
        $collection = collect([$item1, $item2]);
        
        // Simular o método getKeyName do primeiro item (se fosse Eloquent Model)
        $modelMock = Mockery::mock(Model::class);
        $modelMock->shouldReceive('getKeyName')->andReturn('id');
        $collection->shouldReceive('first')->andReturn($modelMock); // Simular que a coleção contém modelos

        // Act
        $key = $this->cacheService->generateCollectionKey($collection, 'active_items');
        
        // Assert
        // A classe do primeiro item é 'stdClass' para objetos anônimos, ou o nome da classe se forem modelos Eloquent.
        // O MD5 é do 'id,id,...' ordenado
        $expectedMd5 = md5('1,2');
        $this->assertEquals('stdClass:active_items:' . $expectedMd5, $key);
    }

    /** @test */
    public function it_sets_default_ttl(): void
    {
        // Act
        $service = $this->cacheService->setDefaultTtl(120); // 120 minutos

        // Assert
        $this->assertEquals(120, $this->getProperty($service, 'defaultTtl'));
    }

    // Helper method to access protected properties for assertion
    protected function getProperty($object, $propertyName)
    {
        $reflection = new \ReflectionClass($object);
        $property = $reflection->getProperty($propertyName);
        $property->setAccessible(true);
        return $property->getValue($object);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }
}