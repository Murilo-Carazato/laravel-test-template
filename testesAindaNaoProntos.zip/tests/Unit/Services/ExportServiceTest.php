<?php

namespace Tests\Unit\Services;

use Tests\TestCase;
use App\Domains\Core\Services\ExportService;
use Illuminate\Database\Eloquent\Builder; // Importar Builder
use Illuminate\Support\Collection; // Importar Collection
use Illuminate\Support\Facades\Storage; // Importar Storage
use Illuminate\Support\Str; // Importar Str
use Illuminate\Support\Facades\Cache; // Importar Cache
use Mockery; // Importar Mockery
use Maatwebsite\Excel\Facades\Excel; // Importar Excel facade (para mockar)
use Illuminate\Support\Facades\Facade;
use League\Csv\Writer; // Importar Writer (para mockar)

class ExportServiceTest extends TestCase
{
    protected ExportService $exportService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->exportService = new ExportService();
        Storage::fake('exports'); // Falsifica o disco de exportação
        Cache::fake(); // Falsifica o cache
        // Mock Str para ter um retorno previsível no nome do arquivo
        Str::shouldReceive('random')->andReturn('random123');
        Str::shouldReceive('slug')->andReturnUsing(fn ($text) => str_replace(' ', '-', strtolower($text)));
    }

    /** @test */
    public function it_generates_a_unique_filename(): void
    {
        $filename = $this->callProtectedMethod($this->exportService, 'generateFilename', ['my-report', 'csv']);
        $this->assertStringContainsString('my-report', $filename);
        $this->assertStringContainsString('random123.csv', $filename);
        $this->assertStringEndsWith('.csv', $filename);
    }

    /** @test */
    public function it_sets_chunk_size(): void
    {
        $this->exportService->setChunkSize(500);
        $this->assertEquals(500, $this->getProperty($this->exportService, 'chunkSize'));
    }

    /** @test */
    public function it_creates_a_background_export_job_and_caches_data(): void
    {
        // Arrange
        $query = Mockery::mock(Builder::class);
        $query->shouldReceive('getQuery')->andReturn(new \Illuminate\Database\Query\Builder(Mockery::mock(\Illuminate\Database\ConnectionInterface::class)));
        $query->shouldReceive('getModel')->andReturn(new \App\Models\User()); // Assume um modelo para o query builder

        $columns = ['name' => 'Name', 'email' => 'Email'];
        $type = 'excel';
        $filename = 'users_export';

        // Mock ProcessExport::dispatch para verificar se foi chamado
        // Mock ProcessExport::dispatch para verificar se foi chamado
        Mockery::mock('alias:App\Jobs\ProcessExport')
            ->shouldReceive('dispatch')
            ->once()
            ->andReturnSelf();
        // Act
        $exportId = $this->exportService->createBackgroundExport($query, $columns, $type, $filename);

        // Assert
        $this->assertIsString($exportId);
        $this->assertNotEmpty($exportId);

        // Verifica se os dados da exportação foram armazenados no cache
        Cache::assertExists('export:' . $exportId);
        $cachedData = Cache::get('export:' . $exportId);

        $this->assertEquals($exportId, $cachedData['id']);
        $this->assertEquals($columns, $cachedData['columns']);
        $this->assertEquals($type, $cachedData['type']);
        $this->assertEquals($filename, $cachedData['filename']);
        $this->assertEquals('pending', $cachedData['status']);
    }

    /** @test */
    public function export_to_csv_creates_file_on_disk(): void
    {
        // Arrange
        $query = Mockery::mock(Builder::class);
        $records = collect([
            (object)['name' => 'User A', 'email' => 'a@example.com'],
            (object)['name' => 'User B', 'email' => 'b@example.com'],
        ]);
        $query->shouldReceive('chunk')->once()->andReturnUsing(function ($size, $callback) use ($records) {
            $callback($records); // Executa o callback com os records
        });

        $columns = ['name' => 'Full Name', 'email' => 'Email Address'];
        $filename = 'my_users';

        // Mock League\Csv\Writer para evitar IO real e verificar interações
        $writerMock = Mockery::mock(Writer::class);
        $writerMock->shouldReceive('setDelimiter')->once()->with(',');
        $writerMock->shouldReceive('setEnclosure')->once()->with('"');
        $writerMock->shouldReceive('setEscape')->once()->with('\\');
        $writerMock->shouldReceive('insertOne')->once()->with(array_values($columns)); // Cabeçalhos
        $writerMock->shouldReceive('insertOne')->once()->with(['User A', 'a@example.com']);
        $writerMock->shouldReceive('insertOne')->once()->with(['User B', 'b@example.com']);
        $writerMock->shouldReceive('getContent')->once()->andReturn("Full Name,Email Address\nUser A,a@example.com\nUser B,b@example.com\n");

        Mockery::mock('alias:' . Writer::class)
            ->shouldReceive('createFromStream')
            ->once()
            ->andReturn($writerMock);

        // Act
        $path = $this->exportService->exportToCsv($query, $columns, $filename, true);

        // Assert
        Storage::assertExists('exports/' . $path);
        // Podemos verificar o conteúdo se o getContent for mocado
        $this->assertStringContainsString('my_users', $path);
        $this->assertStringEndsWith('.csv', $path);
    }

    /** @test */
    public function export_to_excel_creates_file_on_disk(): void
    {
        // Arrange
        $query = Mockery::mock(Builder::class);
        $records = collect([
            (object)['name' => 'User C', 'email' => 'c@example.com'],
        ]);
        $query->shouldReceive('chunk')->once()->andReturnUsing(function ($size, $callback) use ($records) {
            $callback($records); // Executa o callback com os records
        });

        $columns = ['name' => 'User Name', 'email' => 'Email'];
        $filename = 'excel_report';
        // Mock Excel facade
        $excelMock = Mockery::mock('alias:Maatwebsite\Excel\Facades\Excel');
        $excelMock->shouldReceive('store')
            ->once()
            ->andReturn(true);

        // Act
        $path = $this->exportService->exportToExcel($query, $columns, $filename);

        // Assert
        $this->assertStringContainsString('excel_report', $path);
        $this->assertStringEndsWith('.xlsx', $path);
        // Storage::disk('exports')->assertExists($path); // Isso falharia se não mockar a criação do arquivo no storage
    }

    // Helper para acessar métodos protegidos
    protected function callProtectedMethod($obj, $name, array $args = [])
    {
        $class = new \ReflectionClass($obj);
        $method = $class->getMethod($name);
        $method->setAccessible(true);
        return $method->invokeArgs($obj, $args);
    }

    // Helper para acessar propriedades protegidas
    protected function getProperty($obj, $name)
    {
        $class = new \ReflectionClass($obj);
        $property = $class->getProperty($name);
        $property->setAccessible(true);
        return $property->getValue($obj);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }
}