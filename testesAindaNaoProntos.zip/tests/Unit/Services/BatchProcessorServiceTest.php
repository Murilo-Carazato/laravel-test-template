<?php

namespace Tests\Unit\Services;

use Tests\TestCase;
use App\Domains\Core\Services\BatchProcessorService;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable; // Importar Throwable
use App\Models\User; // Importar User (para bulkUpsert)
use Mockery;

class BatchProcessorServiceTest extends TestCase
{
    protected BatchProcessorService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new BatchProcessorService();
        DB::fake();
        Log::fake();
    }

    /** @test */
    public function it_processes_items_successfully_without_transaction(): void
    {
        $items = collect([1, 2, 3, 4, 5]);
        $processedItems = [];
        $callback = function ($item) use (&$processedItems) {
            $processedItems[] = $item * 2;
        };

        $result = $this->service->process($items, $callback, 2, false);

        $this->assertEquals([2, 4, 6, 8, 10], $processedItems);
        $this->assertCount(5, $result['success']);
        $this->assertCount(0, $result['fail']);
        $this->assertEquals(5, $result['statistics']['total']);
        $this->assertEquals(5, $result['statistics']['processed']);
        $this->assertEquals(0, $result['statistics']['failed']);
    }

    /** @test */
    public function it_processes_items_successfully_with_transaction(): void
    {
        $items = collect([1, 2, 3]);
        $processedItems = [];
        $callback = function ($item) use (&$processedItems) {
            $processedItems[] = $item + 1;
        };

        DB::shouldReceive('transaction')
            ->once()
            ->andReturnUsing(function ($callback) {
                $callback();
            });

        $result = $this->service->process($items, $callback, 3, true);

        $this->assertCount(3, $result['success']);
        $this->assertEquals(3, $result['statistics']['processed']);
    }

    /** @test */
    public function it_handles_failures_during_processing(): void
    {
        $items = collect([1, 2, 3]);
        $callback = function ($item) {
            if ($item === 2) {
                throw new \Exception('Processing error for item 2');
            }
            return true;
        };

        $result = $this->service->process($items, $callback, 1, false);

        $this->assertCount(2, $result['success']);
        $this->assertCount(1, $result['fail']);
        $this->assertEquals(3, $result['statistics']['total']);
        $this->assertEquals(3, $result['statistics']['processed']);
        $this->assertEquals(1, $result['statistics']['failed']);
        Log::assertLogged('error', function ($message) {
            return str_contains($message, 'Erro ao processar item: Processing error for item 2');
        });
    }

    /** @test */
    public function it_performs_bulk_upsert_successfully(): void
    {
        $models = collect([
            User::factory()->make(['id' => 1, 'email' => 'user1@example.com', 'name' => 'User One']),
            User::factory()->make(['id' => 2, 'email' => 'user2@example.com', 'name' => 'User Two']),
        ]);
        $uniqueKeys = ['email'];
        $modelClass = User::class;

        Mockery::mock('alias:' . $modelClass)
            ->shouldReceive('upsert')
            ->once()
            ->andReturn([1, 2]);

        $result = $this->service->bulkUpsert($models, $modelClass, $uniqueKeys, 2);

        $this->assertEquals(2, $result['statistics']['upserted']);
        $this->assertEquals(0, $result['statistics']['failed']);
        $this->assertEquals(2, $result['statistics']['total']);
    }

    /** @test */
    public function it_processes_with_retry_successfully_on_first_attempt(): void
    {
        $items = collect([1, 2, 3]);
        $callCount = 0;
        $callback = function ($item) use (&$callCount) {
            $callCount++;
            return true;
        };

        $result = $this->service->processWithRetry($items, $callback, 3);

        $this->assertCount(3, $result['success']);
        $this->assertEquals(3, $result['statistics']['processed']);
        $this->assertEquals(0, $result['statistics']['failed']);
        $this->assertEquals(3, $callCount);
    }

    /** @test */
    public function it_processes_with_retry_and_succeeds_after_retry(): void
    {
        $items = collect([1, 2, 3]);
        $attempts = 0;
        $callback = function ($item) use (&$attempts) {
            if ($item === 2 && $attempts < 1) {
                $attempts++;
                throw new \Exception('Temporary error');
            }
            return true;
        };

        $result = $this->service->processWithRetry($items, $callback, 3);

        $this->assertCount(3, $result['success']);
        $this->assertEquals(4, $result['statistics']['processed']); // 3 items + 1 retry
        $this->assertEquals(0, $result['statistics']['failed']);
        Log::assertLogged('warning', function ($message) {
            return str_contains($message, 'Tentativa 1 falhou para o item: Temporary error');
        });
    }

    /** @test */
    public function it_processes_with_retry_and_fails_after_max_retries(): void
    {
        $items = collect([1]);
        $callback = function ($item) {
            throw new \Exception('Persistent error');
        };

        $result = $this->service->processWithRetry($items, $callback, 2);

        $this->assertCount(0, $result['success']);
        $this->assertCount(1, $result['fail']);
        $this->assertEquals(1, $result['statistics']['total']);
        $this->assertEquals(2, $result['statistics']['processed']); // 2 attempts
        $this->assertEquals(1, $result['statistics']['failed']);

        Log::assertLogged('warning', function ($message) {
            return str_contains($message, 'Tentativa 1 falhou para o item: Persistent error');
        });
        Log::assertLogged('warning', function ($message) {
            return str_contains($message, 'Tentativa 2 falhou para o item: Persistent error');
        });
    }

    /** @test */
    public function it_processes_empty_collection(): void
    {
        $items = collect([]);
        $callback = function ($item) {
            return true;
        };

        $result = $this->service->process($items, $callback);

        $this->assertCount(0, $result['success']);
        $this->assertCount(0, $result['fail']);
        $this->assertEquals(0, $result['statistics']['total']);
        $this->assertEquals(0, $result['statistics']['processed']);
        $this->assertEquals(0, $result['statistics']['failed']);
    }

    /** @test */
    public function it_processes_large_batch_with_multiple_chunks(): void
    {
        $items = collect(range(1, 10));
        $processedItems = [];
        $callback = function ($item) use (&$processedItems) {
            $processedItems[] = $item;
        };

        $result = $this->service->process($items, $callback, 3, false);

        $this->assertCount(10, $result['success']);
        $this->assertEquals(10, $result['statistics']['processed']);
        $this->assertEquals(range(1, 10), $processedItems);
    }

    /** @test */
    public function it_handles_mixed_success_and_failure_in_batch(): void
    {
        $items = collect([1, 2, 3, 4, 5]);
        $callback = function ($item) {
            if ($item % 2 === 0) {
                throw new \Exception("Error processing item $item");
            }
            return true;
        };

        $result = $this->service->process($items, $callback, 2, false);

        $this->assertCount(3, $result['success']); // 1, 3, 5
        $this->assertCount(2, $result['fail']); // 2, 4
        $this->assertEquals(5, $result['statistics']['total']);
        $this->assertEquals(5, $result['statistics']['processed']);
        $this->assertEquals(2, $result['statistics']['failed']);
    }

    /** @test */
    public function it_processes_with_retry_handles_empty_collection(): void
    {
        $items = collect([]);
        $callback = function ($item) {
            return true;
        };

        $result = $this->service->processWithRetry($items, $callback, 3);

        $this->assertCount(0, $result['success']);
        $this->assertCount(0, $result['fail']);
        $this->assertEquals(0, $result['statistics']['total']);
        $this->assertEquals(0, $result['statistics']['processed']);
        $this->assertEquals(0, $result['statistics']['failed']);
    }

    /** @test */
    public function it_bulk_upsert_handles_empty_collection(): void
    {
        $models = collect([]);
        $modelClass = User::class;
        $uniqueKeys = ['email'];

        $result = $this->service->bulkUpsert($models, $modelClass, $uniqueKeys);

        $this->assertEquals(0, $result['statistics']['total']);
        $this->assertEquals(0, $result['statistics']['upserted']);
        $this->assertEquals(0, $result['statistics']['failed']);
    }

    /** @test */
    public function it_processes_with_transaction_rollback_on_failure(): void
    {
        $items = collect([1, 2, 3]);
        $callback = function ($item) {
            if ($item === 2) {
                throw new \Exception('Database error');
            }
            return true;
        };

        DB::shouldReceive('transaction')
            ->once()
            ->andReturnUsing(function ($callback) {
                $callback();
            });

        $result = $this->service->process($items, $callback, 3, true);

        $this->assertCount(2, $result['success']);
        $this->assertCount(1, $result['fail']);
        $this->assertEquals(1, $result['statistics']['failed']);
    }

    /** @test */
    public function it_processes_with_retry_respects_max_retries(): void
    {
        $items = collect([1]);
        $attemptCount = 0;
        $callback = function ($item) use (&$attemptCount) {
            $attemptCount++;
            throw new \Exception('Always fails');
        };

        $result = $this->service->processWithRetry($items, $callback, 3);

        $this->assertEquals(3, $attemptCount);
        $this->assertCount(0, $result['success']);
        $this->assertCount(1, $result['fail']);
        $this->assertEquals(1, $result['statistics']['failed']);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }
}
